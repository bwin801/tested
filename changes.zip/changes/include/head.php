<?php

if(isset($_GET['referrer'])){
	include('includes/includes/codemojo.php');
	$meta_value = $metaService->get($_GET['referrer']);
	if($meta_value['value'] != ""){
		//header('Location: '.$meta_value['value'].'');
		echo '<script> location.href= "'.$meta_value['value'].'"; </script>';
	}
}
?>
<div class="lyt-header">
    <header>
        <a href="/" class="logo-wrap">
            <img src="/images/skillzpot_logo.svg" alt="skillzpot logo">
        </a>
        
        
        <nav>
            <?php 
                // echo "<p>fb</p>";
                 //print_r($profile);
                // echo "<p>normal</p>";
                // echo $_SESSION["fname"];
            //isset($courseDataInfo);
            //echo '<pre>';print_r($homecatData['data']);echo '</pre>';
            ?>
            <?php if( $device==='phone'){?>
        <div class="grp-menu">
            <a class="menu-btn" href="javascript:void(0)">
                <span></span>
                <span></span>
                <span></span>
            </a>
            <div class="nav-wrap-mobile">
                <ul>
                    <li><a class="nav-link" href="/">home</a></li>
                    <li><a class="nav-link" href="/about-us">about</a></li>
                    <?php if(!empty($homecatData['data'])){?>
                     <li>
                         <a class="nav-link" href="#">categories</a>
                         
                         <div class="sub-nav">
                             <ul>
                                <?php foreach ($homecatData['data'] as $courseListvalue) { 
                                 $category_url = '/course-category/'.str_replace(' ', '-', $courseListvalue['category_name']);
                                 ?>
                                 <li><a href="<?php echo $category_url; ?>"><?php echo $courseListvalue['category_name']; ?></a></li>
                                <?php }?>
                             </ul>    
                         </div>
                     </li>
                     <?php }?>
                </ul>
            </div> 
        </div>
        <?php }else{?>
            
             <div class="nav-wrap">
                <ul>
                    <li><a class="nav-link" href="/">home</a></li>
                    <li><a class="nav-link" href="/about-us">about</a></li>
                    <?php if(!empty($homecatData['data'])){?>
                     <li>
                         <a class="nav-link" href="#">categories</a>
                         
                         <div class="sub-nav">
                             <ul>
                                <?php foreach ($homecatData['data'] as $courseListvalue) { 
                                 $category_url = '/course-category/'.str_replace(' ', '-', $courseListvalue['category_name']);
                                 ?>
                                 <li><a href="<?php echo $category_url; ?>"><?php echo $courseListvalue['category_name']; ?></a></li>
                                <?php }?>
                             </ul>    
                         </div>
                         
                         
                     </li>
                     <?php }?> 
                </ul>
            </div> 
            
                
         <?php }?>
            
            <div class="nav-wrap <?php if ($_SESSION["fname"] || $profile){ echo 'typ-icon'; }else{echo 'typ-normal';} ?> pull-right">
                <ul>
                <?php //<li><a href="#" class="nav-link"><span class="vicon vicon-search lg"></span></a></li> ?>
                
                <?php if ($_SESSION["fname"] || $profile){?>
                   <li>
                    <div class="dropdown">
                    <a id="dLabel" href="#" class="drp-menu"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php if (isset($profile)){ 
                                            $f_img = 'https://graph.facebook.com/'.$profile->getId().'/picture?width=40&height=40';
                                        ?>
                                            <img src="<?php echo $f_img; ?>" />
                                        <?php }else{
                                            if ($_SESSION["profile_image"] != "" && $_SESSION["profile_image"] != 0){
                                        ?>
                                            <img src="/images/profile/<?php echo $_SESSION["profile_image"]; ?>" width="40">
                                        <?php }else  if ($_SESSION["fname"]){?>
                                            <img src="/images/avatars/noprofile.png" width="40">
                                        <?php }}?>  </a>
                      <!-- <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Dropdown trigger
                        <span class="caret"></span>
                      </button> -->
                      <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel">
                            <li>
                                <div class="profile-detail">
                                    <div class="profile-img"> 
                                        <?php if (isset($profile)){ 
                                            $f_img = 'https://graph.facebook.com/'.$profile->getId().'/picture?width=70&height=70';
                                        ?>
                                            <img src="<?php echo $f_img; ?>" />
                                        <?php }else{
                                            if ($_SESSION["profile_image"] != "" && $_SESSION["profile_image"] != 0){
                                        ?>
                                            <img src="/images/profile/<?php echo $_SESSION["profile_image"]; ?>" width="70">
                                        <?php }else  if ($_SESSION["fname"]){?>
                                            <img src="/images/avatars/noprofile.png" width="70">
                                        <?php }}?>  
                                    </div>
                                    <div class="detail-wrap">   
                                        <?php
                                            if(isset($profile))
                                            {
                                                echo 'Hi! ' . $profile->getName();
                                            }else{
                                                if ($_SESSION["fname"])
                                                echo "Hi! ".$_SESSION["fname"]." ".$_SESSION["lname"];
                                            }
                                        ?>
                                    </div>
                                </div> 
                            </li>
                            <li><a id="logout_btn" href="/user/profile"><i class="fa fa-desktop" aria-hidden="true"></i> my Dashboard</a></li>
							<?php if(isset($_SESSION['user_type']) && !empty($_SESSION['user_type']) && $_SESSION['user_type']=='2'){?>
                            <?php if($device!=='phone'){ ?>
                            <li><a id="logout_btn" href="/video-external-add"><i class="fa fa-upload" aria-hidden="true"></i> bulk video uploader</a></li>
                            <li><a id="logout_btn" href="/course-external-add"><i class="fa fa-file-video-o" aria-hidden="true"></i> create course</a></li>
							<li><a id="logout_btn" href="/video-external-list"><i class="fa fa-video-camera" aria-hidden="true"></i> video library</a></li>
                            <li><a id="logout_btn" href="/course-external-list"><i class="fa fa-gear" aria-hidden="true"></i> manage course</a></li>
                            <?php } ?>
                            <li><a id="logout_btn" href="/user-announce"><i class="fa fa-envelope" aria-hidden="true"></i> Announcement</a></li>
                            
                            
                            
                            
							<?php } ?>
                            <li><a id="logout_btn" href="/logout"><i class="fa fa-power-off" aria-hidden="true"></i> log out</a></li>

                      </ul>
                    </div>
                    </li>
                <?php } else{?>
                
                     
                    <li><a id="login_btn" class="btn btn-lt-blue reg-btn" href="#"><i class="glyphicon glyphicon-lock"></i> sign in</a></li>
                    <?php if( $device!=='phone'){?>
                    <li><a id="signup-btn-home" class="btn btn-lt-green reg-btn" href="#"><i class="glyphicon glyphicon-pencil"></i> sign up</a></li>
                    <?php }?>
                </ul>
                <?php }?>
            </div>
            <?php if($device==='phone'){ ?>
            <button class="btn btn-srch"><i class="glyphicon glyphicon-search"></i></span></button>
            <?php } ?>
            <div id="header_serch_box" class="mod-cat-search typ-header">
                <?php if($device==='phone'){ ?>
                <button class="btn btn-srch-close"><i class="glyphicon glyphicon-remove"></i></span></button>
                <?php } ?>
                <form name="searchForm" id="searchForm" action="/search-result" method="post">
                    <div class="srch-box-wrap">
                        
                        <div class="input-wrap col-sm-24">
                            <input type="text" id="srch-txt-skill" name="srch-txt-skill" placeholder="Start typing a skill here" />
                        </div>
                        <button class="btn btn-success btn-search" type="submit"><i class="glyphicon glyphicon-search"></i></span></button>
                    </div>
                </form>    
            </div>
        </nav>
    </header>
</div>
