<?php 
require_once 'include_classes/mobile_detect.php';
$detect = new Mobile_Detect;
$device = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
function send($action, $params, $posts = false)
{
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$getData = http_build_query($params);
$postData = "clientSecretKey=c50688eebd8bcd0bc0edfffb3d1d7e49e42d6af1c2d14dca1d512a553c165ce1";
////Replace the caps CLIENT_SECRET_KEY with your video id.
if ($posts)
{
$postData.= "&" . $posts;
}
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
$url = "http://api.vdocipher.com/v2/$action/?$getData";
curl_setopt($curl, CURLOPT_URL, $url);
$html = curl_exec($curl);
curl_close($curl);
return $html;
}
function vdo_play($id, $posts = false)
{
$OTP = send("otp", array(
'video' => $id
) , $posts);
$OTP = json_decode($OTP)->otp;
echo <<<EOF
<div id="vdo$OTP" class="v_player"></div>
<script>
(function(v,i,d,e,o){v[o]=v[o]||{}; v[o].add = v[o].add || function V(a){ (v[o].d=v[o].d||[]).push(a);};
if(!v[o].l) { v[o].l=1*new Date(); a=i.createElement(d), m=i.getElementsByTagName(d)[0];
a.async=1; a.src=e; m.parentNode.insertBefore(a,m);}
})(window,document,'script','//de122v0opjemw.cloudfront.net/vdo.js','vdo');
vdo.add({
o: "$OTP",
theme: ""
});
</script>"; 
EOF;
}
$anno = false;
// / Uncomment this section to add annotation
$annoData = "[" . "{'type':'image', 'url':'https://skillzpot.com/images/logo_overlay.png', 'alpha':'0.3','width':'100', 'x':'20','y':'20'}" .
// "{'type':'image', 'url':'http://draft.skillzpot.com//images/profile/thumbnail/1474561161.png', 'alpha':'0.3', 'x':'10','y':'10'},".
// "{'type':'rtext', 'text':'moving text', 'alpha':'0.8', 'color':'0xFF0000', 'size':'12','interval':'5000'},".
// "{'type':'text', 'text':'static text', 'alpha':'0.5' , 'x':'10', 'y':'100', 'co    lor':'0xFF0000', 'size':'12'}".
"]";
$anno = "annotate=" . urlencode($annoData); 
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $device; ?>">
  <head>
    <?php include $this->basepath.'includes/page_head.php';?>
    <?php include_once $this->basepath.'includes/config.php';?>
    <!--start choose radio-->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery.min.js">
    </script>
    <!--<style>
      ul#stepForm,
      ul#stepForm li {
        margin: 0;
        padding: 0;
      }
      ul#stepForm li {
        list-style: none outside none;
      }
      label {
        margin-top: 10px;
      }
      .help-inline-error {
        color: red;
      }
      /* STEP CSS START*/
      .stepwizard-step p {
        margin-top: 10px;
      }
      .stepwizard-row {
        display: table-row;
      }
      .stepwizard {
        display: table;
        width: 80%;
				margin:0 10%;
        position: relative;
      }
      .stepwizard-step button[disabled] {
        opacity: 1 !important;
        filter: alpha(opacity=100) !important;
      }
      .stepwizard-row .stepwizard-step:before {
            top: 50%;
						bottom: 0;
						position: absolute;
						content: " ";
						left: 0;
						height: 1px;
						background-color: #ccc;
						right: 0;
						z-index: 1;
      }
			.stepwizard-row .stepwizard-step:first-child:before{

			}
      .stepwizard-step {
        display: table-cell;
        text-align: center;
        position: relative;
      }
      .btn-circle {
        width: 30px;
        height: 30px;
        text-align: center;
        padding: 6px 0;
        font-size: 12px;
        line-height: 1.428571429;
        border-radius: 15px;
      }
      .stepwizard-row .disabled-incomplete{
        background:#ffffff;
      }
      .disabled-incomplete{
        pointer-events: none;
        cursor: default;
        opacity: 0.6;
      }
      .disabled-complete{
        color:green;
        font-weight: bold;
      }
      .disabled-active{
        color: #c9302c;
        font-weight: bold;
      }
    </style>-->
    <!--end choose radio-->
  </head>
  <body>
    <!-- start header -->
    <?php include $this->basepath.'includes/head.php';?>
    <!-- end header -->
    <!-- content header -->
    <div class="lyt-admin two-col">
      <div class="l-panel">
        <?php $qString = explode('url=',$_SERVER['QUERY_STRING'])[1]; ?>
        <ul class="menu">
          <li class="<?php if( $qString=="course-external-list"){echo 'active';}else{echo '';}; ?>">
            <a href="../course-external-list">Course List
            </a> 
          </li>
          <li class="<?php if( $qString=="course-external-add"){echo 'active';}else{echo '';}; ?>">
            <a href="../course-external-add">Add Course
            </a>
          </li>
          <ul class="mod-create-course-step">
            <li>
              <a href="" id="vstep-1" class="disabled-active">
                <i class="fa fa-check" aria-hidden="true"></i> Course Name
                
              </a>
            </li>
            <li>
              <a href="" id="vstep-2" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i>Course Description 
              </a>
            </li>
            <li>
              <a href="" id="vstep-3" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Category
              </a>
            </li>
            <li>
              <a href="" id="vstep-4" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Language and Level
              </a>
            </li>
            <li>
              <a href="" id="vstep-5" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Posting Date and Filmed by
              </a>
            </li>
            <li>
              <a href="" id="vstep-6" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Tags
              </a>
            </li>
            <li>
              <a href="" id="vstep-7" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Is this course for me?
              </a>
            </li>
            <li>
              <a href="" id="vstep-8" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> What will I gain from this course?
              </a>
            </li>
            <li>
              <a href="" id="vstep-9" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> How do I prepare for the course?
              </a>
            </li>
            <li>
              <a href="" id="vstep-10" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Pre-view video
              </a>
            </li>
            <li>
              <a href="" id="vstep-11" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> Pre-view image
              </a>
            </li>
            <li>
              <a href="" id="vstep-12" class="disabled-incomplete"><i class="fa fa-check" aria-hidden="true"></i> About me?
              </a>
            </li>
          </ul>
          <!--<li class="<?php if( $qString=="video-external-add"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-add">Add Video Library</a> </li>
<li class="<?php if( $qString=="video-external-list"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-list">Video Library List</a> </li>-->
          <!-- <li class="<?php if( $qString=="course-external-list/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../course-external-list/<?php echo $user_token;?>">Course List</a> </li>
<li class="<?php if( $qString=="course-external-add/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../course-external-add/<?php echo $user_token;?>">Add Course</a> </li> -->
        </ul>
      </div>
      <div class="r-panel">
        <div id="course-add-popup" >
          <h2>Add Course
          </h2>
          <label class="bg-warning bs-info-msg col-sm-24">
            <i class="fa fa-info-circle" aria-hidden="true">
            </i> Use google chrome browser only
          </label>
          <hr/>
          <!--<div class="container">-->
            <div class="row">
              <div class="col-lg-12">
                <div class="stepwizard">
                  <div class="stepwizard-row setup-panel">
                    <div class="stepwizard-step">
                      <a href="" id="step-1" type="button" class="btn btn-danger btn-circle">1
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-2" type="button" class="btn btn-default btn-circle disabled-incomplete">2
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-3" type="button" class="btn btn-default btn-circle disabled-incomplete">3
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-4" type="button" class="btn btn-default btn-circle disabled-incomplete">4
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-5" type="button" class="btn btn-default btn-circle disabled-incomplete">5
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-6" type="button" class="btn btn-default btn-circle disabled-incomplete">6
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-7" type="button" class="btn btn-default btn-circle disabled-incomplete">7
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-8" type="button" class="btn btn-default btn-circle disabled-incomplete">8
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-9" type="button" class="btn btn-default btn-circle disabled-incomplete">9
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-10" type="button" class="btn btn-default btn-circle disabled-incomplete">10
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-11" type="button" class="btn btn-default btn-circle disabled-incomplete">11
                      </a>
                    </div>
                    <div class="stepwizard-step">
                      <a href="" id="step-12" type="button" class="btn btn-default btn-circle disabled-incomplete">12
                      </a>
                    </div>
                  </div>
                </div>
              </div>	
            </div>	
            <div class="clearfix" style="height: 10px;clear: both;">
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="panel panel-primary">
                  <div class="panel-heading">
                    <h3 class="panel-title">create course in quick 12 steps!
                    </h3>
                  </div>
                  <div class="panel-body">
                    <!--<form name="basicform" id="basicform" method="post" action="yourpage.html">-->
                    <form name="basicform" id="basicform" method="post">
                      <div id="sf1" class="frm">
                        <fieldset>
                          <legend>Step 1 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>Assign your Course Name that highlights the crux of the course. For e.g. if you have 20 unique features for Facebook Marketing the course name could be “Master Facebook marketing with 20 brilliant ideas”. Also use all the critical words that is related to the course in the course name as it will help in better listing if a user is searching for a specific topic.</p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="course_name">Course Name : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <input type="text" placeholder="Course Name" id="course_name" name="course_name" class="form-control" autocomplete="off">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-primary open1" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf2" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 2 of 12
                          </legend>
														<div class="bg-warning bs-info-msg">
															<p>Course description should highlight the important aspects of the course. You can detail down important sub-topics that you have catered to in the course. If there are some unique features/examples that you have touched upon in the course, you can let your audience know in this section. </p>
														</div>
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="course_description">Course Description : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <textarea name="course_description" id="course_description" class="form-control" placeholder="Course Description">
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back2" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open2" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf3" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 3 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
															<p>Select an appropriate course category from the drop-down menu. Sub-category should be same as category</p>
														</div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Category : 
                            </label>
                            <div class="col-lg-12">
                              <select class="form-control" name="category_id" id="category_id">
                                <option value="">Select Category
                                </option>
                                <?php foreach($catData['data'] as $cal_val){
																	echo '<option value="'.$cal_val['category_id'].'">'.$cal_val['category_name'].'</option>';
																} ?>
                              </select>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Sub Category : 
                            </label>
                            <div class="col-lg-12">
                              <span id="sub_cat_section">Select Sub Category
                              </span>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back3" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open3" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf4" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 4 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>Select the language of medium. Based on your target audience select whether is the course is for beginners, intermediates or advanced. </p>
													</div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Language : 
                            </label>
                            <div class="col-lg-12">
                              <select class="form-control" name="language" id="language">
                                <option value="">Select Language
                                </option>
                                <?php foreach($config['language'] as $lang_val){
																	echo '<option value="'.$lang_val.'">'.$lang_val.'</option>';
																} ?>
                              </select>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Level : 
                            </label>
                            <div class="col-lg-12">
                              <select class="form-control" name="course_level" id="course_level">
                                <option value="">Select Level
                                </option>
                                <?php foreach($config['course_level'] as $course_level_val){
																	echo '<option value="'.$course_level_val.'">'.$course_level_val.'</option>';
																} ?>
                              </select>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back4" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open4" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf5" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 5 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>This should be the date when you created your course. If you have created the entire course on your own you can use “Self” or your name. You can also give credit to someone who has helped you in filming the course.</p>
													</div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="posting_date">Posting Date : 
                            </label>
                            <div class="col-lg-12">
                              <input type="date" name="posting_date" id="posting_date" placeholder="Posting Date" class="form-control" autocomplete="off">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Filmed By : 
                            </label>
                            <div class="col-lg-12">
                              <input type="text" name="filmed_by" id="filmed_by" placeholder="Filmed By" class="form-control" autocomplete="off">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back5" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open5" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf6" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 6 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>All the important words in the course can be tagged. For e.g. if you have created a course on “Effective habits of a brilliant public speaker” you can tag personality development, speaking, public speaking etc.</p>
													</div>
													
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="uemail">Tags : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <input type="text" name="tags" id="tags" placeholder="Tags" class="form-control" autocomplete="off">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back6" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open6" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf7" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 7 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>In this section who should highlight if the course is targeted for any specific audience. For e.g. “Learn Pre-natal exercise from the comfort of your home” will have pregnant women or women contemplating giving birth in near future.  </p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="uemail">Is this course for me? : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <textarea class="form-control" name="faq1" id="faq1" placeholder="Is this course for me?">
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back7" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open7" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf8" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 8 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>Specifically highlight what knowledge will the subscriber gain once they have completed the course. For e.g. in the course “Mastering Programming and Coding Interview” you can highlight that you will learn Pointers, Arrays, Pointers to Structures etc. The more specifics you cover, the better it is.</p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <label class="control-label" for="uemail">What will I gain from this course? : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <textarea class="form-control" name="faq2" id="faq2" placeholder="What will I gain from this course?">
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back8" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open8" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf9" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 9 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>If there is requirement of any external material, you can highlight in this section. You can also highlight any precautions needed during the course, especially in case of fitness exercises. </p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <label class="control-label" for="uemail">How do I prepare before taking this course? Is there a prerequisite skill set? : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <textarea class="form-control" name="faq3" id="faq3" placeholder="How do I prepare before taking this course? Is there a prerequisite skill set?">
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back9" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open9" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf10" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 10 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>Your preview video should be short and crisp. Ideally you should be able to answer the following question: Who am I? What is my experience in the topic the course is based on? What will I cover in the course? What will you gain from the course after completion? </p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <label class="control-label" for="uemail">Preview Video : 
                              </label>
                            </div>
                            <div class="col-lg-24">
                              <input id="fileupload_chapter_video" class="form-control" type="file" name="file">
                              <label class="bg-warning bs-info-msg typ-small col-sm-24">
                                <!--<i class="fa fa-info-circle" aria-hidden="true">
                                </i>-->  Upload mp4 files only (720 HD and above)
                              </label>
                              <input type="hidden" id="chapter_video"  name="chapter_video" placeholder="chapter_video">
                              <input type="hidden" id="chapter_video_duration"  name="chapter_video_duration" placeholder="chapter_video_duration">
                              <div id="progress" class="progress col-md-24" style="display: none;">
                                <div class="progress-bar progress-bar-success">
                                </div>
                              </div>
                              <!--<div id="files" class="files col-md-24"></div>-->
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back10" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open10" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf11" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 11 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>The image should highlight the course</p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <label class="control-label" for="uemail">Preview Image : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <input id="fileupload_preview_image" type="file" class="form-control" name="files[]" multiple>
                              <label class="bg-warning bs-info-msg typ-small col-sm-24">
                                <i class="fa fa-info-circle" aria-hidden="true">
                                </i> Upload jpg files only ( 1600px X 900px )
                              </label>
                              <input type="hidden" id="preview_image"  class="form-control" name="preview_image" placeholder="preview_image">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back11" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open11" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf12" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 12 of 12
                          </legend>
													<div class="bg-warning bs-info-msg">
														<p>A detailed write up about yourself and your experience. You should also highlight any accolades that you have received from external agencies. You can also link your social media details from My Dashboard-My Settings section.</p>
													</div>
                          <div class="form-group">
                            <div class="col-lg-12"> 
                              <label class="control-label" for="upass1">About me? : 
                              </label>
                            </div>
                            <div class="col-lg-12">
                              <textarea class="form-control" name="about_instructor" id="about_instructor" placeholder="About me?">
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back12" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button> 
                              <button class="btn btn-primary open12" type="button">Submit 
                              </button>
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <!--For Video Preview-->
                      <div id="files" class="files col-md-24">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          <!--</div>-->
          <script src="http://code.jquery.com/jquery-1.9.1.js">
          </script>
          <!--<script type="text/javascript" src="js/steps.js"></script>-->
          <script type="text/javascript" src="jquery.validate.js">
          </script>
          <script type="text/javascript">
            jQuery().ready(function() {
              // validate form on keyup and submit
              var v = jQuery("#basicform").validate({
                rules: {
                  course_name: {
                    required: true,
                  }
                  ,
                  course_description: {
                    required: true,
                  }
                  ,
                  category_id: {
                    required: true,
                  }
                  ,
                  language: {
                    required: true,
                  }
                  ,
                  course_level: {
                    required: true,
                  }
                  ,
                  posting_date: {
                    required: true,
                  }
                  ,
                  filmed_by: {
                    required: true,
                  }
                  ,
                  faq1: {
                    required: true,
                  }
                  ,
                  faq2: {
                    required: true,
                  }
                  ,
                  faq3: {
                    required: true,
                  }
                  ,
                  about_instructor: {
                    required: true,
                  }
                }
                ,
                errorElement: "span",
                errorClass: "help-inline-error",
              }
                                                   );
              //
              // New Tag
              $(".open1").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf2").show("slow");
                  $('#step-1').removeClass('btn-danger').addClass('btn-success');
                  $('#step-2').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-2').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-1').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-2').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/insert.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open2").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf3").show("slow");
                  $('#step-2').removeClass('btn-danger').addClass('btn-success');
                  $('#step-3').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-3').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-2').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-3').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open3").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf4").show("slow");
                  $('#step-3').removeClass('btn-danger').addClass('btn-success');
                  $('#step-4').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-4').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-3').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-4').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open4").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf5").show("slow");
                  $('#step-4').removeClass('btn-danger').addClass('btn-success');
                  $('#step-5').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-5').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-4').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-5').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open5").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf6").show("slow");
                  $('#step-5').removeClass('btn-danger').addClass('btn-success');
                  $('#step-6').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-6').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-5').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-6').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open6").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf7").show("slow");
                  $('#step-6').removeClass('btn-danger').addClass('btn-success');
                  $('#step-7').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-7').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-6').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-7').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open7").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf8").show("slow");
                  $('#step-7').removeClass('btn-danger').addClass('btn-success');
                  $('#step-8').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-8').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-7').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-8').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open8").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf9").show("slow");
                  $('#step-8').removeClass('btn-danger').addClass('btn-success');
                  $('#step-9').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                 );
                  $('#step-9').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-8').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-9').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open9").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf10").show("slow");
                  $('#step-9').removeClass('btn-danger').addClass('btn-success');
                  $('#step-10').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                  );
                  $('#step-10').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-9').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-10').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                               );
              $(".open10").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf11").show("slow");
                  $('#step-10').removeClass('btn-danger').addClass('btn-success');
                  $('#step-11').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                  );
                  $('#step-11').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-10').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-11').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                                );
              $(".open11").click(function() {
                if (v.form()) {
                  $(".frm").hide("fast");
                  $("#sf12").show("slow");
                  $('#step-11').removeClass('btn-danger').addClass('btn-success');
                  $('#step-12').removeClass('disabled-incomplete').addClass('disabled-active').css({
                    'color': 'white'}
                                                                                                  );
                  $('#step-12').removeClass('btn-default').addClass('btn-danger');
                  $('#vstep-11').removeClass('disabled-active').addClass('disabled-complete');
                  $('#vstep-12').removeClass('disabled-incomplete').addClass('disabled-active');
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                  }
                             );
                  return serializedValues;
                }
              }
                                );
              $(".open12").click(function() {
                if (v.form()) {
                  var serializedValues = jQuery("#basicform").serialize();
                  var form_data = {
                    action: 'ajax_data',
                    type: 'post',
                    data: serializedValues,
                  };
                  jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
                    //alert(response);
                    course_id = response;
                  }
                             );
                  //return serializedValues;
                  setTimeout(function(){
                    $("#basicform").html('<h2>Thanks for your time.</h2>');
                    window.location.href = '/chapter-external-add/'+course_id;
                  }
                             , 1000);
                  return false;
                }
              }
                                );
              // Step Tag
              $("#step-1").click(function() {
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf1").show("slow");
              }
                                );
              $("#step-2").click(function() {
                $("#sf1").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf2").show("slow");
              }
                                );
              $("#step-3").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf3").show("slow");
              }
                                );
              $("#step-4").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf4").show("slow");
              }
                                );
              $("#step-5").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf5").show("slow");
              }
                                );
              $("#step-6").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf6").show("slow");
              }
                                );
              $("#step-7").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf7").show("slow");
              }
                                );
              $("#step-8").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf8").show("slow");
              }
                                );
              $("#step-9").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf9").show("slow");
              }
                                );
              $("#step-10").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").hide("fast");
                $("#sf10").show("slow");
              }
                                 );
              $("#step-11").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf12").hide("fast");
                $("#sf11").show("slow");
              }
                                 );
              $("#step-12").click(function() {
                $("#sf1").hide("fast");
                $("#sf2").hide("fast");
                $("#sf3").hide("fast");
                $("#sf4").hide("fast");
                $("#sf5").hide("fast");
                $("#sf6").hide("fast");
                $("#sf7").hide("fast");
                $("#sf8").hide("fast");
                $("#sf9").hide("fast");
                $("#sf10").hide("fast");
                $("#sf11").hide("fast");
                $("#sf12").show("slow");
              }
                                 );
              $("#vstep-1").click(function() {
                $(".frm").hide("fast");
                $("#sf1").show("slow");
              }
                                 );
              $("#vstep-2").click(function() {
                $(".frm").hide("fast");
                $("#sf2").show("slow");
              }
                                 );
              $("#vstep-3").click(function() {
                $(".frm").hide("fast");
                $("#sf3").show("slow");
              }
                                 );
              $("#vstep-4").click(function() {
                $(".frm").hide("fast");
                $("#sf4").show("slow");
              }
                                 );
              $("#vstep-5").click(function() {
                $(".frm").hide("fast");
                $("#sf5").show("slow");
              }
                                 );
              $("#vstep-6").click(function() {
                $(".frm").hide("fast");
                $("#sf6").show("slow");
              }
                                 );
              $("#vstep-7").click(function() {
                $(".frm").hide("fast");
                $("#sf7").show("slow");
              }
                                 );
              $("#vstep-8").click(function() {
                $(".frm").hide("fast");
                $("#sf8").show("slow");
              }
                                 );
              $("#vstep-9").click(function() {
                $(".frm").hide("fast");
                $("#sf9").show("slow");
              }
                                 );
              $("#vstep-10").click(function() {
                $(".frm").hide("fast");
                $("#sf10").show("slow");
              }
                                  );
              $("#vstep-11").click(function() {
                $(".frm").hide("fast");
                $("#sf11").show("slow");
              }
                                  );
              $("#vstep-12").click(function() {
                $(".frm").hide("fast");
                $("#sf12").show("slow");
              }
                                  );
              // Back Tag
              $(".back2").click(function() {
                $(".frm").hide("fast");
                $("#sf1").show("slow");
              }
                               );
              $(".back3").click(function() {
                $(".frm").hide("fast");
                $("#sf2").show("slow");
              }
                               );
              $(".back4").click(function() {
                $(".frm").hide("fast");
                $("#sf3").show("slow");
              }
                               );
              $(".back5").click(function() {
                $(".frm").hide("fast");
                $("#sf4").show("slow");
              }
                               );
              $(".back6").click(function() {
                $(".frm").hide("fast");
                $("#sf5").show("slow");
              }
                               );
              $(".back7").click(function() {
                $(".frm").hide("fast");
                $("#sf6").show("slow");
              }
                               );
              $(".back8").click(function() {
                $(".frm").hide("fast");
                $("#sf7").show("slow");
              }
                               );
              $(".back9").click(function() {
                $(".frm").hide("fast");
                $("#sf8").show("slow");
              }
                               );
              $(".back10").click(function() {
                $(".frm").hide("fast");
                $("#sf9").show("slow");
              }
                                );
              $(".back11").click(function() {
                $(".frm").hide("fast");
                $("#sf10").show("slow");
              }
                                );
              $(".back12").click(function() {
                $(".frm").hide("fast");
                $("#sf11").show("slow");
              }
                                );
            }
                          );
          </script>
        </div>
      </div>
    </div>
    <!-- content header -->
    <!-- Modal -->
    <?php if (isset($videoData) && !empty($videoData) && $videoData != 0) {
foreach ($videoData['data'] as $user_key => $video_val) {		?>
    <div class="modal fade" id="myModal<?= $user_key; ?>" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;
            </button>
            <h4 class="modal-title">
              <?= $video_val['video_name']; ?>
            </h4>
          </div>
          <div class="modal-body">
            <div style="height:200px;">
              <?php echo vdo_play($video_val['video_id'], $anno); ?>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-xs" data-dismiss="modal">Close
            </button>
          </div>
        </div>
      </div>
    </div>
    <?php } } ?>
    <!-- end Modal -->
    <!-- start footer -->
    <?php include $this->basepath.'includes/js.php';?>
    <!-- end footer-->
  </body>
</html>
