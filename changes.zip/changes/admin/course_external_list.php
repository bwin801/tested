<?php 
	require_once 'include_classes/mobile_detect.php';
	$detect = new Mobile_Detect;
	$device = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer') ;

	function send($action, $params, $posts = false){
		    $curl = curl_init();
		    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		    $getData = http_build_query($params);
		    //$postData = "clientSecretKey=285e316971b1c3823840179f0b055854ba47ecec12845ef48324156081485ef8";
			////Replace the caps CLIENT_SECRET_KEY with your video id.
		    $postData = "clientSecretKey=c50688eebd8bcd0bc0edfffb3d1d7e49e42d6af1c2d14dca1d512a553c165ce1";
			////Replace the caps CLIENT_SECRET_KEY with your video id.
		    if ($posts) {
				$postData .= "&". $posts;
			}
		    curl_setopt($curl, CURLOPT_POST, true); 
		    curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
		    $url = "http://api.vdocipher.com/v2/$action/?$getData";
		    curl_setopt($curl, CURLOPT_URL,$url);
		    $html = curl_exec($curl);
		    curl_close($curl);
		    return $html;
		}
		function vdo_play($id, $posts = false){
		    $OTP = send("otp", array(
		        'video'=>$id
		    ), $posts);
		    $OTP = json_decode($OTP)->otp;
			echo <<<EOF
			<div id="vdo$OTP" class="v_player"></div>
			<script>
			(function(v,i,d,e,o){v[o]=v[o]||{}; v[o].add = v[o].add || function V(a){ (v[o].d=v[o].d||[]).push(a);};
			if(!v[o].l) { v[o].l=1*new Date(); a=i.createElement(d), m=i.getElementsByTagName(d)[0];
			a.async=1; a.src=e; m.parentNode.insertBefore(a,m);}
			})(window,document,'script','//de122v0opjemw.cloudfront.net/vdo.js','vdo');
			vdo.add({
				o: "$OTP",
				theme: ""
			});
			</script>";
EOF;
		}
		$anno = false;
     /// Uncomment this section to add annotation
        $annoData = "[".
        "{'type':'image', 'url':'https://skillzpot.com/images/logo_overlay.png', 'alpha':'0.3','width':'100', 'x':'20','y':'20'}".
          // "{'type':'image', 'url':'http://draft.skillzpot.com//images/profile/thumbnail/1474561161.png', 'alpha':'0.3', 'x':'10','y':'10'},".
          // "{'type':'rtext', 'text':'moving text', 'alpha':'0.8', 'color':'0xFF0000', 'size':'12','interval':'5000'},".
          // "{'type':'text', 'text':'static text', 'alpha':'0.5' , 'x':'10', 'y':'100', 'co    lor':'0xFF0000', 'size':'12'}".
          "]";
        $anno = "annotate=". urlencode($annoData);
    
    
         
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $device; ?>">
<head>
	
    <?php include $this->basepath.'includes/page_head.php';?>
    <?php include_once $this->basepath.'includes/config.php';?>
   
</head>

<body>
	
	<!-- start header -->
	<?php include $this->basepath.'includes/head.php';?>
	<!-- end header -->
	<!-- content header -->
	<div class="lyt-admin two-col">
		<div class="l-panel">
			<?php $qString = explode('url=',$_SERVER['QUERY_STRING'])[1]; ?>
			<ul class="menu">
				<li class="<?php if( $qString=="course-external-list"){echo 'active';}else{echo '';}; ?>"><a href="../course-external-list">Course List</a> </li>
				<li class="<?php if( $qString=="course-external-add"){echo 'active';}else{echo '';}; ?>"><a href="../course-external-add">Add Course</a> </li>
<li class="<?php if( $qString=="video-external-add"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-add">Add Video Library</a> </li>
				<li class="<?php if( $qString=="video-external-list"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-list">Video Library List</a> </li>
				<!-- <li class="<?php if( $qString=="course-external-list/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../course-external-list/<?php echo $user_token;?>">Course List</a> </li>
				<li class="<?php if( $qString=="course-external-add/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../course-external-add/<?php echo $user_token;?>">Add Course</a> </li> -->
			</ul>
		</div>
		<div class="r-panel">
			<div class="mod-video-list" id="course-add-popup" >
				<h2>Course Listing</h2>
				<hr/>		
				<?php
				// echo $user_token;
				// echo "<pre>"; print_r($courseData);
				
				if (isset($courseData) && !empty($courseData) && $courseData != 0) {
					    echo '<div class="vdo-lst-wrap">';
					    foreach ($courseData['data'] as $user_key => $course_val) {
					    	echo "<div class='vdo-lst' >";
					       		echo "<div class='info-data'>";
					       			echo '<label class="c_name">' . $course_val['course_name'] . '</label>';
						        	echo '<label><img src="/images/course/thumbnail/' . $course_val['preview_image'] . '" width="100" /></label>';
						        	echo '<label> course id : <span>' . $course_val['id'] . '</span></label>';
							        
							        echo '<label> course level : <span>' . $course_val['course_level'] . '</span></label>';
							        echo '<label> post date : <span>' . $course_val['posting_date'] . '</span></label>';
							        echo '<label> no of lesson : <span>' . $course_val['NoOfChapters'] . '</span></label>';

							        echo '<div class="act_btn">';
							        	
							        	//echo '<a href="../course-external-edit/' . $course_val['id'] ."/". $user_token.'" class="btn btn-primary btn-small"><i class="glyphicon glyphicon-pencil"></i> Edit</a>';
							        	echo '<a href="../course-external-edit/' . $course_val['id'].'" class="btn btn-primary btn-small"><i class="glyphicon glyphicon-pencil"></i> Edit</a>';
							        	//echo '<a rel="' . $course_val['id'] . '" class="course_del_cls btn btn-danger btn-small" href="javascript:void(0)" ><i class="glyphicon glyphicon-trash"></i> Del</a>';
							        echo '</div>';
							        echo '<div class="act_btn">';
							        	//echo '<a href="../chapter-external-add/' . $course_val['id'] ."/". $user_token.'" class="btn btn-success btn-block btn-small"><i class="glyphicon glyphicon-plus"></i> Add lesson</a>';
							        	echo '<a href="../chapter-external-add/' . $course_val['id'] .'" class="btn btn-success btn-block btn-small"><i class="glyphicon glyphicon-plus"></i> Add lesson</a>';
							        echo '</div>';
					       		echo "</div>";
					       		echo vdo_play($course_val['preview_video'], $anno);
					       	echo "</div>";
					    }
					    echo '</div><input type="hidden" name="token" id="token" value="'.$user_token.'">';
				} else {
				    echo 'No record Found';
				}
				// if (isset($courseData) && !empty($courseData) && $courseData != 0) {
				// 	    echo '<table border="1" class="table"><tr><td>Id</td><td>Preview image</td><td>Course Name</td><td>Course Level</td><td>Posting Date</td><td>No Of Lessons</td><td>Add Lesson</td><td>Edit</td><td>Delete</td></tr>';
				// 	    foreach ($courseData['data'] as $user_key => $course_val) {
				// 	        echo '<tr><td>' . $course_val['id'] . '</td>';
				// 	        echo '<td><img src="/images/course/thumbnail/' . $course_val['preview_image'] . '" width="80" /></td>';
				// 	        echo '<td>' . $course_val['course_name'] . '</td>';
				// 	        echo '<td>' . $course_val['course_level'] . '</td>';
				// 	        echo '<td>' . $course_val['posting_date'] . '</td>';
				// 	        echo '<td>' . $course_val['NoOfChapters'] . '</td>';
				// 	        echo '<td><a href="../chapter-external-add/' . $course_val['id'] ."/". $user_token.'">Add</a></td>';
				// 	        echo '<td><a href="../course-external-edit/' . $course_val['id'] ."/". $user_token.'">Edit</a></td>';
				// 	        echo '<td><a rel="' . $course_val['id'] . '" class="course_del_cls" href="javascript:void(0)">Del</a></td></tr>';
				// 	    }
				// 	    echo '</div><input type="hidden" name="token" id="token" value="'.$user_token.'">';
				// } else {
				//     echo 'No record Found';
				// }
			?>
			</div>
		</div>
	</div>
	<!-- content header -->

	<!-- start footer -->
	<?php include $this->basepath.'includes/js.php';?>
	<!-- end footer-->
</body>

</html>
