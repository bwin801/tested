<?php 
	require_once 'include_classes/mobile_detect.php';
	$detect = new Mobile_Detect;
	$device = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer') ;

	function send($action, $params, $posts = false){
		    $curl = curl_init();
		    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		    $getData = http_build_query($params);
		    //$postData = "clientSecretKey=285e316971b1c3823840179f0b055854ba47ecec12845ef48324156081485ef8";
		    $postData = "clientSecretKey=c50688eebd8bcd0bc0edfffb3d1d7e49e42d6af1c2d14dca1d512a553c165ce1";
			////Replace the caps CLIENT_SECRET_KEY with your video id.
		    if ($posts) {
				$postData .= "&". $posts;
			}
		    curl_setopt($curl, CURLOPT_POST, true); 
		    curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
		    $url = "http://api.vdocipher.com/v2/$action/?$getData";
		    curl_setopt($curl, CURLOPT_URL,$url);
		    $html = curl_exec($curl);
		    curl_close($curl);
		    return $html;
		}
		function vdo_play($id, $posts = false){
		    $OTP = send("otp", array(
		        'video'=>$id
		    ), $posts);
		    $OTP = json_decode($OTP)->otp;
			echo <<<EOF
			<div id="vdo$OTP" class="v_player" ></div>
			<script>
			(function(v,i,d,e,o){v[o]=v[o]||{}; v[o].add = v[o].add || function V(a){ (v[o].d=v[o].d||[]).push(a);};
			if(!v[o].l) { v[o].l=1*new Date(); a=i.createElement(d), m=i.getElementsByTagName(d)[0];
			a.async=1; a.src=e; m.parentNode.insertBefore(a,m);}
			})(window,document,'script','//de122v0opjemw.cloudfront.net/vdo.js','vdo');
			vdo.add({
				o: "$OTP",
				theme: ""
			});
			</script>";
EOF;
		}
		$anno = false;
     /// Uncomment this section to add annotation
        $annoData = "[".
        "{'type':'image', 'url':'https://skillzpot.com/images/logo_overlay.png', 'alpha':'0.3','width':'100', 'x':'20','y':'20'}".
          // "{'type':'image', 'url':'http://draft.skillzpot.com//images/profile/thumbnail/1474561161.png', 'alpha':'0.3', 'x':'10','y':'10'},".
          // "{'type':'rtext', 'text':'moving text', 'alpha':'0.8', 'color':'0xFF0000', 'size':'12','interval':'5000'},".
          // "{'type':'text', 'text':'static text', 'alpha':'0.5' , 'x':'10', 'y':'100', 'co    lor':'0xFF0000', 'size':'12'}".
          "]";
        $anno = "annotate=". urlencode($annoData);
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $device; ?>">
<head>
	
    <?php include $this->basepath.'includes/page_head.php';?>
    <?php include_once $this->basepath.'includes/config.php';?>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		$('input[type="radio"]').click(function(){
			var inputValue = $(this).attr("value");
			if(inputValue == 'library' || inputValue == 'lesson')
			{
				var targetBox = $("." + inputValue);
				$(".box").not(targetBox).hide();
				$(targetBox).show();
			} else {
				var arr = inputValue.split("&");
				document.getElementById('video_library').value = arr[0];
				document.getElementById('chapter_video_duration').value = arr[1];
			}
			
		});
	});
	</script>
	
   <!-- <style type="text/css">
    	.vdo-lst-wrap {
		display: table;
	}
	.vdo-lst-wrap .vdo-lst {
		float: left;
		width: 360px;
		margin: 10px;
		position: relative;
		border: solid 1px #999;
	}
	.vdo-lst-wrap .vdo-lst .info-data {
		margin-top: 224px;
		padding: 10px 90px 10px 10px;
		font-size: 14px;
		line-height: 18px;
		min-height: 103px;
	}
	.vdo-lst-wrap .vdo-lst .info-data .act-btns {
		position: absolute;
		right: 0;
		bottom: 0;
	}
	.vdo-lst-wrap .vdo-lst .info-data .lesson-name {
		display: block;
		font-weight: bold;
	}
	.vdo-lst-wrap .vdo-lst .info-data .lessonId {
		font-size: 12px;
		text-transform: uppercase;
	}
	.vdo-lst-wrap .vdo-lst .info-data .download-pdf {
		display: block;
		font-size: 11px;
		margin: 5px 0;
	}
	.vdo-lst-wrap .vdo-lst .info-data .lesson-description {
		display: block;
	}
	.v_player {
		position: absolute;
		left: 0px;
		top: 0px;
		height: 240px;
		right: 0px;
	}
	ul#stepForm,
	ul#stepForm li {
		margin: 0;
		padding: 0;
	}
	ul#stepForm li {
		list-style: none outside none;
	}
	label {
		margin-top: 10px;
	}
	.help-inline-error {
		color: red;
	}
	/* STEP CSS START*/

	.stepwizard-step p {
		margin-top: 10px;
	}
	.stepwizard-row {
		display: table-row;
	}
	.stepwizard {
		display: table;
		width: 50%;
		position: relative;
	}
	.stepwizard-step button[disabled] {
		opacity: 1 !important;
		filter: alpha(opacity=100) !important;
	}
	.stepwizard-row:before {
		top: 14px;
		bottom: 0;
		position: absolute;
		content: " ";
		width: 100%;
		height: 1px;
		background-color: #ccc;
		z-order: 0;
	}
	.stepwizard-step {
		display: table-cell;
		text-align: center;
		position: relative;
	}
	.btn-circle {
		width: 30px;
		height: 30px;
		text-align: center;
		padding: 6px 0;
		font-size: 12px;
		line-height: 1.428571429;
		border-radius: 15px;
	}
	.disabled-incomplete{
        pointer-events: none;
        cursor: default;
        opacity: 0.6;
    }
	.disabled-complete{
		color:green;
		font-weight: bold;
    }
	.disabled-active{
		color: #c9302c;
		font-weight: bold;
    }
    </style>-->
		<style>
		.row-info{
			cursor:move;
		}
		.row-info:hover td{
			background:#fef5d6;
		}
		.ui-sortable-helper td{
			background:#fef5d6;
		}
		</style>
</head>

<body>
	
	<!-- start header -->
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css">
	<?php include $this->basepath.'includes/head.php';?>
	<!-- end header -->

		<!-- content header -->
	<div class="lyt-admin two-col">
		<div class="l-panel">
			<?php $qString = explode('url=',$_SERVER['QUERY_STRING'])[1]; 
			$str = explode('/',$qString); ?>
			<ul class="menu">
				<li class="<?php if( $qString=="course-external-list"){echo 'active';}else{echo '';}; ?>"><a href="../course-external-list">Course List</a> </li>
				<li class="<?php if( $qString=="course-external-add"){echo 'active';}else{echo '';}; ?>"><a href="../course-external-add">Add Course</a> </li>

				<li class="<?php if( $qString=="video-external-add"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-add">Add Video Library</a> </li>
				<li class="<?php if( $qString=="video-external-list"){echo 'active';}else{echo '';}; ?>"><a href="../video-external-list">Video Library List</a> </li>
				<!-- <li class="<?php if( $qString=="course-external-list/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../../course-external-list/<?php echo $user_token;?>">Course List</a> </li>
				<li class="<?php if( $qString=="course-external-add/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="../../course-external-add/<?php echo $user_token;?>">Add Course</a> </li> -->
			</ul>
		</div>
		<div class="r-panel">
			<div id="chapter-add-popup" class="row">
				<div class='fromEle col-sm-12'>
				<h4>Add lesson for <?php echo $courseData['data'][0]['course_name']; ?></h4>
				
				<div class="stepwizard col-md-offset-3">
					<div class="stepwizard-row setup-panel">
					  <div class="stepwizard-step">
						<a href="" id="step-1" type="button" class="btn btn-danger btn-circle">1</a>
						<!--<p>Step 1</p>-->
					  </div>
					  <div class="stepwizard-step">
						<a href="" id="step-2" type="button" class="btn btn-default btn-circle disabled-incomplete">2</a>
						<!--<p>Step 2</p>-->
					  </div>
					  <div class="stepwizard-step">
						<a href="" id="step-3" type="button" class="btn btn-default btn-circle disabled-incomplete">3</a>
						<!--<p>Step 3</p>-->
					  </div>
					  <div class="stepwizard-step">
						<a href="" id="step-4" type="button" class="btn btn-default btn-circle disabled-incomplete">4</a>
						<!--<p>Step 4</p>-->
					  </div>
					</div>
				</div>
				
				<div class="panel panel-primary">
				  <div class="panel-heading">
					 <h3 class="panel-title">create course in quick 4 steps!</h3>
				  </div>
				  <div class="panel-body">
					 <form name="basicform" id="basicform" method="post">
						
						<div id="sf1" class="frm">
						   <fieldset>
							  <legend>Step 1 of 4</legend>
							  <div class="form-group">
								 <div class="col-lg-10">
								 <label class="control-label" for="chapter_name">lesson name : </label>
								 </div>
								 <div class="col-lg-24">
									<input type="text" placeholder="Lesson name should be Lesson 1, Lesson 2 and so on..." id="chapter_name" name="chapter_name" class="form-control" autocomplete="off">
									<input type="hidden" name="course_id" value="<?= $str[1]; ?>" placeholder="chapter_video">
								 </div>
							  </div>
							  <div class="clearfix" style="height: 10px;clear: both;"></div>
							  <div class="form-group">
								 <div class="col-lg-12">
									<button class="btn btn-primary open1" type="button">Next <span class="fa fa-arrow-right"></span></button> 
								 </div>
							  </div>
						   </fieldset>
						</div>
						
						<div id="sf2" class="frm" style="display: none;">
						   <fieldset>
							  <legend>Step 2 of 4</legend>
							  <div class="form-group">
								 <div class="col-lg-10">
								 <label class="control-label" for="chapter_description">lesson description : </label>
								 </div>
								 <div class="col-lg-24">
									<textarea class="form-control" name="chapter_description" id="chapter_description" placeholder="Lesson description should not be more than 15 words"></textarea>
								 </div>
							  </div>
							  <div class="clearfix" style="height: 10px;clear: both;"></div>
							  <div class="form-group">
								 <div class="col-lg-12">
									<button class="btn btn-warning back2" type="button"><span class="fa fa-arrow-left"></span> Back</button> 
									<button class="btn btn-primary open2" type="button">Next <span class="fa fa-arrow-right"></span></button> 
								 </div>
							  </div>
						   </fieldset>
						</div>
						
						<div id="sf3" class="frm" style="display: none;">
						   <fieldset>
							  <legend>Step 3 of 4</legend>
							  <label><input type="radio" name="vdoRadio" value="lesson"> Single Video Upload</label>
							  <label><input type="radio" name="vdoRadio" value="library"> Video Library</label>
							  
							  <div class="form-group lesson box" style="display:none;">
								 <div class="col-lg-10">
								 <label class="control-label" for="video">Lesson Video : </label>
								 </div>
								 <div class="col-lg-24">
									<input id="fileupload_chapter_video" class="form-control" type="file" name="file">
									<label class="bg-warning bs-info-msg typ-small col-sm-24"><i class="fa fa-info-circle" aria-hidden="true"></i>  Upload mp4 files only (720 HD and above)</label>
									<input type="hidden" id="chapter_video"  name="chapter_video" placeholder="chapter_video">
									<input type="hidden" id="chapter_video_duration"  name="chapter_video_duration" placeholder="chapter_video_duration">
									<input type="hidden" id="chapter_video_name"  name="chapter_video_name">
									<div id="progress" class="progress">
										<div class="progress-bar progress-bar-success"></div>
									</div>
									<!--<div id="files" class="files"></div>-->
								 </div>
							  </div>
							  
						<div class="form-group library box" style="display:none;">	  
							  <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
					<tr>
						<th>#</th>
						<th>Name</th>
						<th>Preview</th>
					</tr>
					</thead>
					<tbody>
				<?php
				// echo $user_token;
				// echo "<pre>"; print_r($videoData);
				
				if (isset($videoData) && !empty($videoData) && $videoData != 0) {
					    echo '<div class="vdo-lst-wrap">';
					    foreach ($videoData['data'] as $user_key => $video_val) { ?>
							<tr>
								<td><input type="radio" name="vdoRadio" value="<?= $video_val['video_id'].'&'.$video_val['video_duration']; ?>"></td>
								<td><?= $video_val['video_name']; ?></td>
								<td><button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#myModal<?= $user_key; ?>">Preview</button></td>
							</tr> 
							<?php
					    }
					    echo '</div>';
				} else {
				    echo 'No record Found';
				}
			?>
				</tbody>
				</table>
				<div class="clearfix" style="height: 10px;clear: both;"></div>
							  <div class="form-group library box">
								 <div class="col-lg-24">
									<a href="/video-external-add">Add More Video On Library</a>
								 </div>
							  </div>
				</div>
				<input type="hidden" name="video_library" id="video_library">
							  <div class="clearfix" style="height: 10px;clear: both;"></div>
							  <div class="form-group">
								 <div class="col-lg-12">
									<button class="btn btn-warning back3" type="button"><span class="fa fa-arrow-left"></span> Back</button> 
									<button class="btn btn-primary open3" type="button">Next <span class="fa fa-arrow-right"></span></button> 
								 </div>
							  </div>
						   </fieldset>
						</div>
						
						<div id="sf4" class="frm" style="display: none;">
						   <fieldset>
							  <legend>Step 4 of 4</legend>
							  <div class="form-group">
								 <div class="col-lg-24"> 
								 <label class="control-label" for="upass1">lesson pdf : </label>
								 </div>
								 <div class="col-lg-24">
									<input id="fileupload_chapter_pdf" type="file" class="form-control" name="files[]" multiple accept="application/pdf">
									<label class="bg-warning bs-info-msg typ-small col-sm-24"><i class="fa fa-info-circle" aria-hidden="true"></i>  Upload pdf file only. The file should have a lesson video attached mandatorily.</label>
									<input type="hidden" id="chapter_pdf"  name="chapter_pdf" placeholder="chapter_pdf">
								 </div>
							  </div>
							  
							  <div class="form-group">
								 <div class="col-lg-24"> 
								 <label class="control-label" for="upass1">lesson url : </label>
								 </div>
								 <div class="col-lg-24">
									<input id="chapter_url" type="url" class="form-control" name="chapter_url">
								 </div>
							  </div>
							  <div class="clearfix" style="height: 10px;clear: both;"></div>
							  <div class="form-group">
								 <div class="col-lg-18">
									<button class="btn btn-warning back4" type="button"><span class="fa fa-arrow-left"></span> Back</button> 
									<button class="btn btn-info more" type="button"><span class="fa fa-plus"></span> Add More</button>
									<button class="btn btn-primary open4" type="button">Submit </button>
								 </div>
							  </div>
						   </fieldset>
						</div>
						<!--File Upload-->
						<div id="files" class="files"></div>
					 </form>
				  </div>
				  
			   </div>
				
			</div>
			
			<div>
					<!-- <?php include $this->basepath.'partials/admin/course_view.php';?> -->
					<!--<h4><?php echo $courseData['data'][0]['course_name']; ?></h4>-->
					<hr/>
				</div>
				<div class="well col-sm-12">	
				<h4>Existing Lessons of <?php echo $courseData['data'][0]['course_name']; ?></h4>
				<hr>
				
				<div class="table-responsive">
				<form name="frmQA" method="POST" action="http://draft.skillzpot.com/partials/admin/update_order.php"/>
				<input type = "hidden" name="chapter_order" id="chapter_order" />	
				<div style="position:relative;">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
					<tr>
						<th style="width:25%">Name</th>
						<th style="width:50%">Description</th>
						<th style="width:20%">Preview</th>
						<th style="width:5%"> Action</th>
					</tr>
					</thead>
					<tbody id="sortable-row" >
				<?php
				if (isset($chapterData) && !empty($chapterData) && $chapterData != 0) {
					    echo '<div class="vdo-lst-wrap">';
					    foreach ($chapterData['data'] as $chapter_key => $chapter_val) { ?>
							<tr class="row-info" style="width:100%" id=<?= $chapter_val['chapter_id']; ?>>
								<!--<td><?= $chapter_val['chapter_order']; ?></td>-->
								<td style="width:25%"><?= $chapter_val['chapter_name']; ?></td>
								<td style="width:50%"><?= $chapter_val['chapter_description']; ?></td>
								<td style="width:20%"><button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#myChapterModal<?= $chapter_key; ?>">Preview</button></td>
								<td style="width:5%"><?= '<a href="/chapter-external-edit/'.$chapter_val['chapter_id'].'" class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>'; ?></td>
							</tr>
						<?php
					    }
				} else {
				    echo 'No record Found';
				}
			?>
				</tbody>
				</table>
				</div>			
				<input type="submit" class="btnSave" name="submit" value="Save Order" onClick="saveOrder();" />
				</form>
				
				</div>
				</div>
			
			</div>
				
		</div>
	</div>

	<!-- content header -->
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<!--<script type="text/javascript" src="js/steps.js"></script>-->
	<script type="text/javascript" src="jquery.validate.js"></script>
			
			<script type="text/javascript">
			  jQuery().ready(function() {

				// validate form on keyup and submit
				var v = jQuery("#basicform").validate({
				  rules: {
					chapter_name: {
					  required: true,
					},
					chapter_description: {
					  required: true,
					}
				  },
				  errorElement: "span",
				  errorClass: "help-inline-error",
				});
				// New Tag
				$(".open1").click(function() {
				  if (v.form()) {
					$(".frm").hide("fast");
					$("#sf2").show("slow");
					$('#step-1').removeClass('btn-danger').addClass('btn-success');
					$('#step-2').removeClass('disabled-incomplete').addClass('disabled-active').css({'color': 'white'});
					$('#step-2').removeClass('btn-default').addClass('btn-danger');
					
					var serializedValues = jQuery("#basicform").serialize();
					var form_data = {
						action: 'ajax_data',
						type: 'post',
						data: serializedValues,
					};
					jQuery.post('http://draft.skillzpot.com/partials/admin/insert_chapter.php', form_data, function(response) {
					//alert(response);
					});
					return serializedValues;
				  }
				});
				
				$(".open2").click(function() {
				  if (v.form()) {
					$(".frm").hide("fast");
					$("#sf3").show("slow");
					$('#step-2').removeClass('btn-danger').addClass('btn-success');
					$('#step-3').removeClass('disabled-incomplete').addClass('disabled-active').css({'color': 'white'});
					$('#step-3').removeClass('btn-default').addClass('btn-danger');
					
					var serializedValues = jQuery("#basicform").serialize();
					var form_data = {
						action: 'ajax_data',
						type: 'post',
						data: serializedValues,
					};
					jQuery.post('http://draft.skillzpot.com/partials/admin/update_chapter.php', form_data, function(response) {
					//alert(response);
					});
					return serializedValues;
					
				  }
				});

				$(".open3").click(function() {
				  if (v.form()) {
					$(".frm").hide("fast");
					$("#sf4").show("slow");
					$('#step-3').removeClass('btn-danger').addClass('btn-success');
					$('#step-4').removeClass('disabled-incomplete').addClass('disabled-active').css({'color': 'white'});
					$('#step-4').removeClass('btn-default').addClass('btn-danger');
					
					var serializedValues = jQuery("#basicform").serialize();
					var form_data = {
						action: 'ajax_data',
						type: 'post',
						data: serializedValues,
					};
					jQuery.post('http://draft.skillzpot.com/partials/admin/update_chapter.php', form_data, function(response) {
					//alert(response);
					});
					return serializedValues;
					
				  }
				});
				
				$(".open4").click(function() {
				  if (v.form()) {
					
					var serializedValues = jQuery("#basicform").serialize();
					var form_data = {
						action: 'ajax_data',
						type: 'post',
						data: serializedValues,
					};
					jQuery.post('http://draft.skillzpot.com/partials/admin/update_chapter.php', form_data, function(response) {
					//alert(response);
					});
					//return serializedValues;
				
					setTimeout(function(){
						$("#basicform").html('<h2>Thanks for your time.</h2>');
						window.location.href = '/chapter-external-add/'+"<?=$str[1];?>";
					}, 1000);
					return false;
				  }
				});
				//Step Tag
				$("#step-1").click(function() {
				  $("#sf2").hide("fast");
				  $("#sf3").hide("fast");
				  $("#sf4").hide("fast");
				  $("#sf1").show("slow");
				});
				$("#step-2").click(function() {
				  $("#sf1").hide("fast");
				  $("#sf3").hide("fast");
				  $("#sf4").hide("fast");
				  $("#sf2").show("slow");
				});
				$("#step-3").click(function() {
				  $("#sf1").hide("fast");
				  $("#sf2").hide("fast");
				  $("#sf4").hide("fast");
				  $("#sf3").show("slow");
				});
				$("#step-4").click(function() {
				  $("#sf1").hide("fast");
				  $("#sf2").hide("fast");
				  $("#sf3").hide("fast");
				  $("#sf4").show("slow");
				}); 
				// Back Tag
				$(".back2").click(function() {
				  $(".frm").hide("fast");
				  $("#sf1").show("slow");
				});
				
				$(".back3").click(function() {
				  $(".frm").hide("fast");
				  $("#sf2").show("slow");
				});

				$(".back4").click(function() {
				  $(".frm").hide("fast");
				  $("#sf3").show("slow");
				});
				
				$(".more").click(function() {
					window.location.href = '/chapter-external-add/'+"<?=$str[1];?>"
				  /*$(".frm").hide("fast");
				  $("#sf1").show("slow");
				  $('#step-1').removeClass('btn-success').addClass('btn-danger');
				  $('#step-2').removeClass('btn-success').addClass('btn-default');
				  $('#step-3').removeClass('btn-success').addClass('btn-default');
				  $('#step-4').removeClass('btn-success').addClass('btn-default');
				  $('#files').val('');
				  $('#basicform')[0].reset();*/
				});
				
			  });
			</script>
	<!-- start footer -->
	<?php include $this->basepath.'includes/js.php';?>
	<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
	<script>
	$(document).ready(function() {
		$('#example').DataTable();
	} );
	$('#example').dataTable( {
	  paginate: false,
	  //scrollY: 300
	} );
	
	(function ($) {
    $.fn.extend({
        tableAddCounter: function (options) {

        // set up default options 
        var defaults = {
            title: 'sl.no',
            start: 1,
            id: false,
            cssClass: 'sl'
        };

            // Overwrite default options with user provided
        var options = $.extend({}, defaults, options);

            return $(this).each(function () {
                // Make sure this is a table tag
                if ($(this).is('table')) {

                    // Add column title unless set to 'false'
                    if (!options.title) options.title = '';
                    $('th:first-child, thead td:first-child', this).each(function () {
                        var tagName = $(this).prop('tagName');
                        $(this).before('<' + tagName + ' rowspan="' + $('thead tr').length + '" class="' + options.cssClass + '" id="' + options.id + '">' + options.title + '</' + tagName + '>');
                    });

                    // Add counter starting counter from 'start'
                    $('tbody td:first-child', this).each(function (i) {
                        $(this).before('<td><div class="move-icon">' + (options.start + i) + '</div></td>');
                    });

                }
            });
        }
    });
	})(jQuery);

	$(document).ready(function () {
		$('.table').tableAddCounter();
		$.getScript("http://code.jquery.com/ui/1.9.2/jquery-ui.js").done(function (script, textStatus) { $('tbody').sortable();$(".alert-info").alert('close');$(".alert-success").show(); });
	});
	
	function saveOrder() {
		var selectedLanguage = new Array();
		$('tbody#sortable-row tr').each(function() {
		selectedLanguage.push($(this).attr("id"));
		});
		document.getElementById("chapter_order").value = selectedLanguage;
	}
	</script>
	<!-- end footer-->
	<!-- Modal -->
	<?php if (isset($videoData) && !empty($videoData) && $videoData != 0) {
		foreach ($videoData['data'] as $user_key => $video_val) {		?>
		 <div class="modal fade" id="myModal<?= $user_key; ?>" role="dialog">
			<div class="modal-dialog">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title"><?= $video_val['video_name']; ?></h4>
				</div>
				<div class="modal-body">
					<div style="height:200px;">
					<?php echo vdo_play($video_val['video_id'], $anno); ?>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default btn-xs" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>
	<?php } } ?>
	
	<?php if (isset($chapterData) && !empty($chapterData) && $chapterData != 0) {
		 foreach ($chapterData['data'] as $chapter_key => $chapter_val) {?>
		 <div class="modal fade" id="myChapterModal<?= $chapter_key; ?>" role="dialog">
			<div class="modal-dialog">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title"><?= $chapter_val['chapter_name']; ?></h4>
				</div>
				<div class="modal-body">
					<div style="height:200px;">
					<?php echo vdo_play($chapter_val['chapter_video'], $anno); ?>
					</div>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default btn-xs" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>
	<?php } } ?>
	<!-- end Modal -->
</body>

</html>