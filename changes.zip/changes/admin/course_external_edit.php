<?php 
require_once 'include_classes/mobile_detect.php';
$detect = new Mobile_Detect;
$device = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
function send($action, $params, $posts = false)
{
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$getData = http_build_query($params);
$postData = "clientSecretKey=c50688eebd8bcd0bc0edfffb3d1d7e49e42d6af1c2d14dca1d512a553c165ce1";
////Replace the caps CLIENT_SECRET_KEY with your video id.
if ($posts)
{
$postData.= "&" . $posts;
}
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
$url = "http://api.vdocipher.com/v2/$action/?$getData";
curl_setopt($curl, CURLOPT_URL, $url);
$html = curl_exec($curl);
curl_close($curl);
return $html;
}
function vdo_play($id, $posts = false)
{
$OTP = send("otp", array(
'video' => $id
) , $posts);
$OTP = json_decode($OTP)->otp;
echo <<<EOF
<div id="vdo$OTP" class="v_player"></div>
<script>
(function(v,i,d,e,o){v[o]=v[o]||{}; v[o].add = v[o].add || function V(a){ (v[o].d=v[o].d||[]).push(a);};
if(!v[o].l) { v[o].l=1*new Date(); a=i.createElement(d), m=i.getElementsByTagName(d)[0];
a.async=1; a.src=e; m.parentNode.insertBefore(a,m);}
})(window,document,'script','//de122v0opjemw.cloudfront.net/vdo.js','vdo');
vdo.add({
o: "$OTP",
theme: ""
});
</script>"; 
EOF;
}
$anno = false;
// / Uncomment this section to add annotation
$annoData = "[" . "{'type':'image', 'url':'https://skillzpot.com/images/logo_overlay.png', 'alpha':'0.3','width':'100', 'x':'20','y':'20'}" .
// "{'type':'image', 'url':'http://draft.skillzpot.com//images/profile/thumbnail/1474561161.png', 'alpha':'0.3', 'x':'10','y':'10'},".
// "{'type':'rtext', 'text':'moving text', 'alpha':'0.8', 'color':'0xFF0000', 'size':'12','interval':'5000'},".
// "{'type':'text', 'text':'static text', 'alpha':'0.5' , 'x':'10', 'y':'100', 'co    lor':'0xFF0000', 'size':'12'}".
"]";
$anno = "annotate=" . urlencode($annoData);
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $device; ?>">
  <head>
    <?php include $this->basepath.'includes/page_head.php';?>
    <?php include_once $this->basepath.'includes/config.php';?>
    <!--start choose radio-->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery.min.js">
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
        $('input[type="radio"]').click(function(){
          var inputValue = $(this).attr("value");
          if(inputValue == 'library' || inputValue == 'lesson')
          {
            var targetBox = $("." + inputValue);
            $(".box").not(targetBox).hide();
            $(targetBox).show();
          }
          else {
            document.getElementById('video_library').value = inputValue;
          }
        }
                                      );
      }
                       );
    </script>
    <!--<style>
      ul#stepForm,
      ul#stepForm li {
        margin: 0;
        padding: 0;
      }
      ul#stepForm li {
        list-style: none outside none;
      }
      label {
        margin-top: 10px;
      }
      .help-inline-error {
        color: red;
      }
      /* STEP CSS START*/
      .stepwizard-step p {
        margin-top: 10px;
      }
      .stepwizard-row {
        display: table-row;
      }
      .stepwizard {
        display: table;
        width: 50%;
        position: relative;
      }
      .stepwizard-step button[disabled] {
        opacity: 1 !important;
        filter: alpha(opacity=100) !important;
      }
      .stepwizard-row:before {
        top: 14px;
        bottom: 0;
        position: absolute;
        content: " ";
        width: 100%;
        height: 1px;
        background-color: #ccc;
        z-order: 0;
      }
      .stepwizard-step {
        display: table-cell;
        text-align: center;
        position: relative;
      }
      .btn-circle {
        width: 30px;
        height: 30px;
        text-align: center;
        padding: 6px 0;
        font-size: 12px;
        line-height: 1.428571429;
        border-radius: 15px;
      }
      .disabled-incomplete{
        pointer-events: none;
        cursor: default;
        opacity: 0.6;
      }
      .disabled-complete{
        color:green;
        font-weight: bold;
      }
      .disabled-active{
        color: #c9302c;
        font-weight: bold;
      }
    </style>-->
    <!--end choose radio-->
  </head>
  <body>
    <!-- start header -->
    <?php include $this->basepath.'includes/head.php';?>
    <!-- end header -->
    <!-- content header -->
    <div class="lyt-admin two-col">
      <div class="l-panel">
        <?php $qString = explode('url=',$_SERVER['QUERY_STRING'])[1]; ?>
        <ul class="menu">
          <li class="<?php if( $qString=="course-external-list"){echo 'active';}else{echo '';}; ?>">
            <a href="../course-external-list">Course List
            </a> 
          </li>
          <li class="<?php if( $qString=="course-external-add"){echo 'active';}else{echo '';}; ?>">
            <a href="../course-external-add">Add Course
            </a> 
          </li>
          <ul class="mod-create-course-step">
            <li>
              <a href="" id="vstep-1" class="disabled-active">
                <i class="fa fa-check" aria-hidden="true">
                </i> Course Name
              </a>
            </li>
            <li>
              <a href="" id="vstep-2" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i>Course Description 
              </a>
            </li>
            <li>
              <a href="" id="vstep-3" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Category
              </a>
            </li>
            <li>
              <a href="" id="vstep-4" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Language and Level
              </a>
            </li>
            <li>
              <a href="" id="vstep-5" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Posting Date and Filmed by
              </a>
            </li>
            <li>
              <a href="" id="vstep-6" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Tags
              </a>
            </li>
            <li>
              <a href="" id="vstep-7" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Is this course for me?
              </a>
            </li>
            <li>
              <a href="" id="vstep-8" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> What will I gain from this course?
              </a>
            </li>
            <li>
              <a href="" id="vstep-9" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> How do I prepare for the course?
              </a>
            </li>
            <li>
              <a href="" id="vstep-10" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Pre-view video
              </a>
            </li>
            <li>
              <a href="" id="vstep-11" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> Pre-view image
              </a>
            </li>
            <li>
              <a href="" id="vstep-12" class="disabled-complete">
                <i class="fa fa-check" aria-hidden="true">
                </i> About me?
              </a>
            </li>
          </ul>
          <!--<p><a href="" id="vstep-1" class="disabled-active step1">Step 1</a></p>
<p><a href="" id="vstep-2" class="disabled-complete step2">Step 2</a></p>
<p><a href="" id="vstep-3" class="disabled-complete step3">Step 3</a></p>
<p><a href="" id="vstep-4" class="disabled-complete step4">Step 4</a></p>
<p><a href="" id="vstep-5" class="disabled-complete step5">Step 5</a></p>
<p><a href="" id="vstep-6" class="disabled-complete step6">Step 6</a></p>
<p><a href="" id="vstep-7" class="disabled-complete step7">Step 7</a></p>
<p><a href="" id="vstep-8" class="disabled-complete step8">Step 8</a></p>
<p><a href="" id="vstep-9" class="disabled-complete step9">Step 9</a></p>
<p><a href="" id="vstep-10" class="disabled-complete step10">Step 10</a></p>
<p><a href="" id="vstep-11" class="disabled-complete step11">Step 11</a></p>
<p><a href="" id="vstep-12" class="disabled-complete step12">Step 12</a></p>-->
          <li class="<?php if( $qString=="video-external-add"){echo 'active';}else{echo '';}; ?>">
            <a href="../video-external-add">Add Video Library
            </a> 
          </li>
          <li class="<?php if( $qString=="video-external-list"){echo 'active';}else{echo '';}; ?>">
            <a href="../video-external-list">Video Library List
            </a> 
          </li>
          <!-- <li class="<?php if( $qString=="course-external-list/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="/course-external-list/<?php echo $user_token;?>">Course List</a> </li>
<li class="<?php if( $qString=="course-external-add/".$user_token){echo 'active';}else{echo '';}; ?>"><a href="/course-external-add/<?php echo $user_token;?>">Add Course</a> </li> -->
        </ul>
      </div>
      <div class="r-panel">	
        <div class="mod-video-list" id="course-edit-popup">
          <h2>Edit Course
          </h2>
          <label class="bg-warning bs-info-msg col-sm-24">
            <i class="fa fa-info-circle" aria-hidden="true">
            </i> Use google chrome browser only
          </label>
          
            <div class="row">
              <div class="col-lg-12">
                <div class="stepwizard">
                  <div class="stepwizard-row setup-panel">
                    <div class="stepwizard-step">
                      <button id="step-1" class="btn btn-danger btn-circle step1" type="button">1
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-2" class="btn btn-success btn-circle step2" type="button">2
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-3" class="btn btn-success btn-circle step3" type="button">3
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-4" class="btn btn-success btn-circle step4" type="button">4
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-5" class="btn btn-success btn-circle step5" type="button">5
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-6" class="btn btn-success btn-circle step6" type="button">6
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-7" class="btn btn-success btn-circle step7" type="button">7
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-8" class="btn btn-success btn-circle step8" type="button">8
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-9" class="btn btn-success btn-circle step9" type="button">9
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-10" class="btn btn-success btn-circle step10" type="button">10
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-11" class="btn btn-success btn-circle step11" type="button">11
                      </button>
                    </div>
                    <div class="stepwizard-step">
                      <button id="step-12" class="btn btn-success btn-circle step12" type="button">12
                      </button>
                      <!--<p>Step 12</p>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;">
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="panel panel-primary">
                  <div class="panel-heading">
                    <h3 class="panel-title">create course in quick 12 steps!
                    </h3>
                  </div>
                  <div class="panel-body">
                    <!--<form name="basicform" id="basicform" method="post" action="yourpage.html">-->
                    <form name="basicform" id="basicform" method="post">
                      <div id="sf1" class="frm">
                        <fieldset>
                          <legend>Step 1 of 12
                          </legend>
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="course_name">Course Name : 
                              </label>
                            </div>
                            <div class="col-lg-24">
                              <input type="text" placeholder="Course Name" id="course_name" name="course_name" class="form-control" autocomplete="off" value="<?php echo $courseData['data'][0]['course_name']; ?>">
                              <input type="hidden" name="id" value="<?php echo $courseData['data'][0]['id']; ?>">
                              <input type="hidden" name="type" value="update">
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-success next1" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button>
                              <button class="btn btn-primary open1" type="button">Done Editing
                              </button>						
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf2" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 2 of 12
                          </legend>
                          <div class="form-group">
                            <div class="col-lg-10">
                              <label class="control-label" for="course_description">Course Description : 
                              </label>
                            </div>
                            <div class="col-lg-24">
                              <textarea name="course_description" id="course_description" class="form-control" placeholder="Course Description">
                                <?php echo $courseData['data'][0]['course_description']; ?>
                              </textarea>
                            </div>
                          </div>
                          <div class="clearfix" style="height: 10px;clear: both;">
                          </div>
                          <div class="form-group">
                            <div class="col-lg-12">
                              <button class="btn btn-warning back2" type="button">
                                <span class="fa fa-arrow-left">
                                </span> Back
                              </button>
                              <button class="btn btn-success next2" type="button">Next 
                                <span class="fa fa-arrow-right">
                                </span>
                              </button>
                              <button class="btn btn-primary open2" type="button">Done Editing
                              </button> 
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div id="sf3" class="frm" style="display: none;">
                        <fieldset>
                          <legend>Step 3 of 12
                          </legend>
                          <div class="form-group">
                            <label class="col-lg-6 control-label" for="uemail">Category : 
                            </label>
                            <div class="col-lg-24">
                              <select class="form-control" name="category_id" id="category_id">
                                <?php foreach($catData['data'] as $cat_val){ ?>
                                <option value="<?php echo $cat_val['category_id']; ?>" 
                                        <?php if($cat_val['category_id']==$courseData["data"][0]["category_id"]) echo 'selected';?>>
                                <?php echo $cat_val['category_name'];?>
                                </option>
                              <?php }	?>
                              </select>
                          </div>
                          </div>
                        <div class="clearfix" style="height: 10px;clear: both;">
                        </div>
                        <div class="form-group">
                          <label class="col-lg-6 control-label" for="uemail">Sub Category : 
                          </label>
                          <div class="col-lg-24">
                            <span id="sub_cat_section">
                              <?php echo $courseData['data'][0]['sub_category_name']; ?>
                              <input type="hidden" id="sub_category_id" name="sub_category_id" placeholder="sub_category_id" value="<?php echo $courseData['data'][0]['sub_category_id']; ?>">
                            </span>
                          </div>
                        </div>
                        <div class="clearfix" style="height: 10px;clear: both;">
                        </div>
                        <div class="form-group">
                          <div class="col-lg-12"> 
                            <button class="btn btn-warning back3" type="button">
                              <span class="fa fa-arrow-left">
                              </span> Back
                            </button>
                            <button class="btn btn-success next3" type="button">Next 
                              <span class="fa fa-arrow-right">
                              </span>
                            </button>
                            <button class="btn btn-primary open3" type="button">Done Editing
                            </button> 
                          </div>
                        </div>
                        </fieldset>
                      </div>
                    <div id="sf4" class="frm" style="display: none;">
                      <fieldset>
                        <legend>Step 4 of 12
                        </legend>
                        <div class="form-group">
                          <label class="col-lg-6 control-label" for="uemail">Language : 
                          </label>
                          <div class="col-lg-24">
                            <select class="form-control" name="language" id="language">
                              <option value="">Select Language
                              </option>
                              <?php foreach($config['language'] as $lang_val) { ?>
                              <option value="<?php echo $lang_val; ?>" 
                                      <?php if($lang_val==$courseData["data"][0]["language"]) echo 'selected';?>>
                              <?php echo $lang_val;?>
                              </option>
                            <?php }	?>
                            </select>
                        </div>
                        </div>
                      <div class="clearfix" style="height: 10px;clear: both;">
                      </div>
                      <div class="form-group">
                        <label class="col-lg-6 control-label" for="uemail">Level : 
                        </label>
                        <div class="col-lg-24">
                          <select class="form-control" name="course_level" id="course_level">
                            <option value="">Select Level
                            </option>
                            <?php foreach($config['course_level'] as $course_level_val) { ?>
                            <option value="<?php echo $course_level_val; ?>" 
                                    <?php if($course_level_val==$courseData["data"][0]["course_level"]) echo 'selected';?>>
                            <?php echo $course_level_val;?>
                            </option>
                          <?php }	?>
                          </select>
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back4" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next4" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open4" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                    </fieldset>
                </div>
                <div id="sf5" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 5 of 12
                    </legend>
                    <div class="form-group">
                      <label class="col-lg-6 control-label" for="posting_date">Posting Date : 
                      </label>
                      <div class="col-lg-24">
                        <input type="date" name="posting_date" id="posting_date" placeholder="Posting Date" class="form-control" autocomplete="off" value="<?php echo $courseData['data'][0]['posting_date']; ?>">
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <label class="col-lg-6 control-label" for="uemail">Filmed By : 
                      </label>
                      <div class="col-lg-24">
                        <input type="text" name="filmed_by" id="filmed_by" placeholder="Filmed By" class="form-control" autocomplete="off" value="<?php echo $courseData['data'][0]['filmed_by']; ?>">
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back5" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next5" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open5" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf6" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 6 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-10">
                        <label class="control-label" for="uemail">Tags : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <input type="text" name="tags" id="tags" placeholder="Tags" class="form-control" autocomplete="off" value="<?php echo $courseData['data'][0]['tags']; ?>">
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12"> 
                        <button class="btn btn-warning back6" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next6" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open6" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf7" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 7 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-10">
                        <label class="control-label" for="uemail">Is this course for me? : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <textarea class="form-control" name="faq1" id="faq1" placeholder="Is this course for me?">
                          <?php echo $courseData['data'][0]['faq1']; ?>
                        </textarea>
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back7" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next7" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open7" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf8" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 8 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-24">
                        <label class="control-label" for="uemail">What will I gain from this course? : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <textarea class="form-control" name="faq2" id="faq2" placeholder="What will I gain from this course?">
                          <?php echo $courseData['data'][0]['faq2']; ?>
                        </textarea>
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12"> 
                        <button class="btn btn-warning back8" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next8" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open8" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf9" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 9 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-24">
                        <label class="control-label" for="uemail">How do I prepare before taking this course? Is there a prerequisite skill set? : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <textarea class="form-control" name="faq3" id="faq3" placeholder="How do I prepare before taking this course? Is there a prerequisite skill set?">
                          <?php echo $courseData['data'][0]['faq3']; ?>
                        </textarea>
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back9" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next9" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open9" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf10" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 10 of 12
                    </legend>
                    <!--<label><input type="radio" name="vdoRadio" value="lesson"> Single Video Upload</label>
											<label><input type="radio" name="vdoRadio" value="library"> Video Library</label>-->
                    <div class="form-group">
                      <div class="col-lg-24">
                        <label class="control-label" for="uemail">Preview Video : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <input id="fileupload_chapter_video" class="form-control" type="file" name="file">
                        <label class="bg-warning bs-info-msg typ-small col-sm-24">
                          <i class="fa fa-info-circle" aria-hidden="true">
                          </i>  Upload mp4 files only (720 HD and above)
                        </label>
                        <input type="hidden" id="chapter_video" name="chapter_video" value="<?php echo $courseData['data'][0]['preview_video']; ?>" placeholder="chapter_video">
                        <input type="hidden" id="chapter_video_duration" name="chapter_video_duration" placeholder="chapter_video_duration" value="<?php echo $courseData['data'][0]['chapter_video_duration']; ?>">
                        <div id="progress" class="progress col-md-24" style="display: none;">
                          <div class="progress-bar progress-bar-success">
                          </div>
                        </div>
                        <!--<div id="files" class="files col-md-24"></div>-->
                      </div>
                    </div>
                    <!--<div class="form-group library box" style="display:none;">	  
										<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
										<tr>
										<th>#</th>
										<th>Name</th>
										<th>Preview</th>
										</tr>
										</thead>
										<tbody>
											<?php
											if (isset($videoData) && !empty($videoData) && $videoData != 0) {
											echo '<div class="vdo-lst-wrap">';
											foreach ($videoData['data'] as $user_key => $video_val) { ?>
											<tr>
											<td><input type="radio" name="vdoRadio" value="<?= $video_val['video_id']; ?>"></td>
											<td><?= $video_val['video_name']; ?></td>
											<td><button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#myModal<?= $user_key; ?>">Preview</button></td>
											</tr> 
											<?php
											}
											echo '</div>';
											} else {
											echo 'No record Found';
											} ?>
											</tbody>
											</table>
											<div class="clearfix" style="height: 10px;clear: both;"></div>
											<div class="form-group library box">
											<div class="col-lg-12">
											<a href="/video-external-add">Add More Video On Library</a>
											</div>
											</div>
											</div>
											<input type="hidden" name="video_library" id="video_library">-->
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back10" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next10" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open10" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf11" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 11 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-24">
                        <label class="control-label" for="uemail">Preview Image : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <input id="fileupload_preview_image" type="file" class="form-control" name="files[]" multiple>
                        <label class="bg-warning bs-info-msg typ-small col-sm-24">
                          <i class="fa fa-info-circle" aria-hidden="true">
                          </i> Upload jpg files only ( 1600px X 900px )
                        </label>
                        <input type="hidden" id="preview_image"  class="form-control" name="preview_image" placeholder="preview_image" value="<?php echo $courseData['data'][0]['preview_image']; ?>">
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back11" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next11" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open11" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="sf12" class="frm" style="display: none;">
                  <fieldset>
                    <legend>Step 12 of 12
                    </legend>
                    <div class="form-group">
                      <div class="col-lg-24"> 
                        <label class="control-label" for="upass1">About me? : 
                        </label>
                      </div>
                      <div class="col-lg-24">
                        <textarea class="form-control" name="about_instructor" id="about_instructor" placeholder="About me?">
                          <?php echo $courseData['data'][0]['about_instructor']; ?>
                        </textarea>
                      </div>
                    </div>
                    <div class="clearfix" style="height: 10px;clear: both;">
                    </div>
                    <div class="form-group">
                      <div class="col-lg-12">
                        <button class="btn btn-warning back12" type="button">
                          <span class="fa fa-arrow-left">
                          </span> Back
                        </button>
                        <button class="btn btn-success next12" type="button">Next 
                          <span class="fa fa-arrow-right">
                          </span>
                        </button>
                        <button class="btn btn-primary open12" type="button">Done Editing
                        </button> 
                      </div>
                    </div>
                  </fieldset>
                </div>
                <div id="files" class="files col-md-24">
                </div>
                </form>
            </div>
          
        </div>
      </div>
    </div>
    </div>
  </div>
</div>
<!-- content header -->
<script src="http://code.jquery.com/jquery-1.9.1.js">
</script>
<!--<script type="text/javascript" src="js/steps.js"></script>-->
<script type="text/javascript" src="jquery.validate.js">
</script>
<script type="text/javascript">
  jQuery().ready(function() {
    // validate form on keyup and submit
    var v = jQuery("#basicform").validate({
      rules: {
        course_name: {
          required: true,
        }
        ,
        course_description: {
          required: true,
        }
        ,
        upass1: {
          required: true,
          minlength: 6,
          maxlength: 15,
        }
        ,
        upass2: {
          required: true,
          minlength: 6,
          equalTo: "#upass1",
        }
      }
      ,
      errorElement: "span",
      errorClass: "help-inline-error",
    }
                                         );
    // go to step through
    $(".step1").click(function() {
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf1").show("slow");
      $('#vstep-1').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-1').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step2").click(function() {
      $("#sf1").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf2").show("slow");
      $('#vstep-2').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-2').removeClass('btn-success').addClass('btn-danger');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step3").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf3").show("slow");
      $('#vstep-3').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-3').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step4").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf4").show("slow");
      $('#vstep-4').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-4').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step5").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf5").show("slow");
      $('#vstep-5').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-5').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step6").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf6").show("slow");
      $('#vstep-6').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-6').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step7").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf7").show("slow");
      $('#vstep-7').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-7').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step8").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf8").show("slow");
      $('#vstep-8').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-8').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step9").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf9").show("slow");
      $('#vstep-9').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                       );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-9').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                     );
    $(".step10").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").hide("fast");
      $("#sf10").show("slow");
      $('#vstep-10').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                        );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-10').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                      );
    $(".step11").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf12").hide("fast");
      $("#sf11").show("slow");
      $('#vstep-11').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                        );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-12').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#step-11').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
      $('#step-12').removeClass('btn-danger').addClass('btn-success');
    }
                      );
    $(".step12").click(function() {
      $("#sf1").hide("fast");
      $("#sf2").hide("fast");
      $("#sf3").hide("fast");
      $("#sf4").hide("fast");
      $("#sf5").hide("fast");
      $("#sf6").hide("fast");
      $("#sf7").hide("fast");
      $("#sf8").hide("fast");
      $("#sf9").hide("fast");
      $("#sf10").hide("fast");
      $("#sf11").hide("fast");
      $("#sf12").show("slow");
      $('#vstep-12').css({
        'color': '#c9302c', 'font-weight': 'bold'}
                        );
      $('#vstep-2').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-3').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-4').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-5').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-6').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-7').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-8').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-9').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#vstep-10').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-11').css({
        'font-weight': 'normal', 'color': 'green'}
                        );
      $('#vstep-1').css({
        'font-weight': 'normal', 'color': 'green'}
                       );
      $('#step-12').removeClass('btn-success').addClass('btn-danger');
      $('#step-2').removeClass('btn-danger').addClass('btn-success');
      $('#step-3').removeClass('btn-danger').addClass('btn-success');
      $('#step-4').removeClass('btn-danger').addClass('btn-success');
      $('#step-5').removeClass('btn-danger').addClass('btn-success');
      $('#step-6').removeClass('btn-danger').addClass('btn-success');
      $('#step-7').removeClass('btn-danger').addClass('btn-success');
      $('#step-8').removeClass('btn-danger').addClass('btn-success');
      $('#step-9').removeClass('btn-danger').addClass('btn-success');
      $('#step-10').removeClass('btn-danger').addClass('btn-success');
      $('#step-11').removeClass('btn-danger').addClass('btn-success');
      $('#step-1').removeClass('btn-danger').addClass('btn-success');
    }
                      );
    // New Tag
    $(".next1").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf2").show("slow");
        $('#step-1').removeClass('btn-danger').addClass('btn-success');
        $('#step-2').removeAttr('disabled').trigger('click');
        $('#step-2').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-1').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-2').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next2").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf3").show("slow");
        $('#step-2').removeClass('btn-danger').addClass('btn-success');
        $('#step-3').removeAttr('disabled').trigger('click');
        $('#step-3').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-2').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-3').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next3").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf4").show("slow");
        $('#step-3').removeClass('btn-danger').addClass('btn-success');
        $('#step-4').removeAttr('disabled').trigger('click');
        $('#step-4').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-3').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-4').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next4").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf5").show("slow");
        $('#step-4').removeClass('btn-danger').addClass('btn-success');
        $('#step-5').removeAttr('disabled').trigger('click');
        $('#step-5').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-4').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-5').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next5").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf6").show("slow");
        $('#step-5').removeClass('btn-danger').addClass('btn-success');
        $('#step-6').removeAttr('disabled').trigger('click');
        $('#step-6').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-5').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-6').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next6").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf7").show("slow");
        $('#step-6').removeClass('btn-danger').addClass('btn-success');
        $('#step-7').removeAttr('disabled').trigger('click');
        $('#step-7').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-6').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-7').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next7").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf8").show("slow");
        $('#step-7').removeClass('btn-danger').addClass('btn-success');
        $('#step-8').removeAttr('disabled').trigger('click');
        $('#step-8').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-7').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-8').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next8").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf9").show("slow");
        $('#step-8').removeClass('btn-danger').addClass('btn-success');
        $('#step-9').removeAttr('disabled').trigger('click');
        $('#step-9').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-8').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-9').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next9").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf10").show("slow");
        $('#step-9').removeClass('btn-danger').addClass('btn-success');
        $('#step-10').removeAttr('disabled').trigger('click');
        $('#step-10').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-9').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-10').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                     );
    $(".next10").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf11").show("slow");
        $('#step-10').removeClass('btn-danger').addClass('btn-success');
        $('#step-11').removeAttr('disabled').trigger('click');
        $('#step-11').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-10').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-11').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                      );
    $(".next11").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf12").show("slow");
        $('#step-11').removeClass('btn-danger').addClass('btn-success');
        $('#step-12').removeAttr('disabled').trigger('click');
        $('#step-12').removeClass('btn-default').addClass('btn-danger');
        $('#vstep-11').removeClass('disabled-active').addClass('disabled-complete');
        $('#vstep-12').removeClass('disabled-incomplete').addClass('disabled-active');
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        return serializedValues;
      }
    }
                      );
    $(".next12").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
          course_id = response;
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/chapter-external-add/'+course_id;
        }
                   , 1000);
        return false;
      }
    }
                      );
    // Done Submiting
    $(".open1").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open2").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open3").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open4").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open5").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open6").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open7").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open8").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open9").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                     );
    $(".open10").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                      );
    $(".open11").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                      );
    $(".open12").click(function() {
      if (v.form()) {
        var serializedValues = jQuery("#basicform").serialize();
        var form_data = {
          action: 'ajax_data',
          type: 'post',
          data: serializedValues,
        };
        jQuery.post('http://draft.skillzpot.com/partials/admin/update.php', form_data, function(response) {
          //alert(response);
        }
                   );
        //return serializedValues;
        setTimeout(function(){
          $("#basicform").html('<h2>Thanks for your time.</h2>');
          window.location.href = '/course-external-list';
        }
                   , 1000);
        return false;
      }
    }
                      );
    // Back Tag
    $(".back2").click(function() {
      $(".frm").hide("fast");
      $("#sf1").show("slow");
    }
                     );
    $(".back3").click(function() {
      $(".frm").hide("fast");
      $("#sf2").show("slow");
    }
                     );
    $(".back4").click(function() {
      $(".frm").hide("fast");
      $("#sf3").show("slow");
    }
                     );
    $(".back5").click(function() {
      $(".frm").hide("fast");
      $("#sf4").show("slow");
    }
                     );
    $(".back6").click(function() {
      $(".frm").hide("fast");
      $("#sf5").show("slow");
    }
                     );
    $(".back7").click(function() {
      $(".frm").hide("fast");
      $("#sf6").show("slow");
    }
                     );
    $(".back8").click(function() {
      $(".frm").hide("fast");
      $("#sf7").show("slow");
    }
                     );
    $(".back9").click(function() {
      $(".frm").hide("fast");
      $("#sf8").show("slow");
    }
                     );
    $(".back10").click(function() {
      $(".frm").hide("fast");
      $("#sf9").show("slow");
    }
                      );
    $(".back11").click(function() {
      $(".frm").hide("fast");
      $("#sf10").show("slow");
    }
                      );
    $(".back12").click(function() {
      $(".frm").hide("fast");
      $("#sf11").show("slow");
    }
                      );
  }
                );
</script>
<!-- start footer -->
<?php include $this->basepath.'includes/js.php';?>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
</script>
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js">
</script>
<script>
  $(document).ready(function() {
    $('#example').DataTable();
  }
                   );
  $('#example').dataTable( {
    paginate: false,
    //scrollY: 300
  }
                         );
</script>
<!-- end footer-->
<!-- Modal -->
<?php if (isset($videoData) && !empty($videoData) && $videoData != 0) {
foreach ($videoData['data'] as $user_key => $video_val) {		?>
<div class="modal fade" id="myModal<?= $user_key; ?>" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;
        </button>
        <h4 class="modal-title">
          <?= $video_val['video_name']; ?>
        </h4>
      </div>
      <div class="modal-body">
        <div style="height:200px;">
          <?php echo vdo_play($video_val['video_id'], $anno); ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-xs" data-dismiss="modal">Close
        </button>
      </div>
    </div>
  </div>
</div>
<?php } } ?>
<!-- end Modal -->
</body>
</html>
